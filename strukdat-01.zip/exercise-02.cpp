/**
 * Author   : Prayudha A.L
 * NPM      : 140810180008
 * Deskripsi: Program ini membedakan kelipatan 3 dan 5 dengan fizz atau buzz
 * Tahun    : 2019
*/

#include <iostream>
using namespace std;

float cel2Fah(float celcius){
    float temp;
    return temp = (celcius * 9 / 5) + 32;
}

int main(){
    float celcius = 9;
    float fahrenheit = cel2Fah(celcius);
    cout<<"temp is "<<fahrenheit;
}
/**
 * Author   : Prayudha A.L
 * NPM      : 140810180008
 * Deskripsi: Program ini membedakan kelipatan 3 dan 5 dengan fizz atau buzz
 * Tahun    : 2019
*/

#include <iostream>
using namespace std;

void fizzbuzz(){
    for(int i=1; i<=100; i++){
        if(i%3==0 && i%5==0){
            cout<<"Fizz Buzz"<<endl;
        }
        else if(i%3==0){
            cout<<"Fizz"<<endl;
        }  
        else if(i%5==0){
            cout<<"Buzz"<<endl;
        }
        else{
            cout<<i<<endl;
        }
    }
}

int main(){
    fizzbuzz();
}
